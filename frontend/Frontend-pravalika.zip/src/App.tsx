import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import FaceEmotionPage from './pages/FaceEmotionPage';
import VoiceEmotionPage from './pages/VoiceEmotionPage';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/face-emotion" element={<FaceEmotionPage />} />
          <Route path="/voice-emotion" element={<VoiceEmotionPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
